package com.cts.semaphores;

import java.sql.Connection;
import java.util.concurrent.Semaphore;

public class DbConnectionDemo extends Thread{
	
	private Semaphore semaphore;
	private Connection conn;
	public DbConnectionDemo(Semaphore sema)
	{
		
		semaphore=sema;
		conn= DbConnection.getConnection();
		
		
	}

	@Override
	public void run() {
		try {
			semaphore.acquire();
			System.out.println(Thread.currentThread().getName()+"Acquired connection...");
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			semaphore.release();
			System.out.println(Thread.currentThread().getName()+"released the  connection...");
		}
		
		
		
	}
	
	

}
