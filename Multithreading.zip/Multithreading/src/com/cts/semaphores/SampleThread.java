package com.cts.semaphores;

import java.util.concurrent.Semaphore;

public class SampleThread extends Thread {
	Semaphore semaphore;
	 
	SampleThread(Semaphore semaphore){
	      this.semaphore = semaphore;
	   }
	 
	   public void run() {
	      try {
	    	  
	    	 	         semaphore.acquire();
	         System.out.println("Hello " + this.getName());
	         try {
	            sleep(2000);
	         } catch (Exception e) {}
	      } catch (InterruptedException ie) {
	      } finally {
	         semaphore.release();
	         System.out.println("Goodbye " + this.getName());
	      }
	   }
}
