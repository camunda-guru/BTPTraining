package com.cts.semaphores;

import java.util.concurrent.Semaphore;

public class DbTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Semaphore semaphores =new Semaphore(2);
		DbConnectionDemo t1=new DbConnectionDemo(semaphores);
		DbConnectionDemo t2=new DbConnectionDemo(semaphores);
		DbConnectionDemo t3=new DbConnectionDemo(semaphores);
		DbConnectionDemo t4=new DbConnectionDemo(semaphores);
		t1.start();
		t2.start();
		t3.start();
		t4.start();
	}

}
