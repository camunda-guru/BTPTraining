package com.cts.semaphores;

import java.util.concurrent.Semaphore;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//num specifies the initial permit count. Thus, num specifies the number of threads
		//that can access a shared resource at any one time.
		//Semaphore(int num)
		//By default, waiting threads are granted a permit in an
		//undefined order.
		//By setting how to true, you can ensure that waiting threads are granted a
		//permit in the order in which they requested access.
		//Semaphore(int num, boolean how)
		Semaphore s1 = new Semaphore(1);
		   Semaphore s2 = new Semaphore(1);

		   Thread t = new Thread(new DoubleResourceGrabber(s1, s2));
		   // now reverse them ... here comes trouble!
		   Thread t2 = new Thread(new DoubleResourceGrabber(s2, s1));

		   t.start();
		   t2.start();

		   try {
			t.join();
			 t2.join();
			   System.out.println("We got lucky!");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
	}

}
