package com.cts.semaphores;

import java.sql.Connection;

public class DbConnection {

	public static Connection getConnection()
	{
		return null;
	}
}
