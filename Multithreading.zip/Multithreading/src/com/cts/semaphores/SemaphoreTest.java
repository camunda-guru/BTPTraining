package com.cts.semaphores;

import java.util.concurrent.Semaphore;

public class SemaphoreTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		      Semaphore semaphore=new Semaphore(3);
		      SampleThread mt1 = new   SampleThread(semaphore);
		      SampleThread mt2 = new SampleThread(semaphore);
		      SampleThread  mt3 = new SampleThread(semaphore);
		      SampleThread mt4 = new SampleThread(semaphore);
		      mt1.start();
		      mt2.start();
		      mt3.start();
		      mt4.start();
		   
	}

}
