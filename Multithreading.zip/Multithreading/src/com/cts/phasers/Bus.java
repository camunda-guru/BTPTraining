package com.cts.phasers;

import java.util.Random;
import java.util.concurrent.Phaser;
import java.util.concurrent.TimeUnit;
//We have 3 buses and a road trip. 
//All buses must leave at the same time, and neither can leave for the next city 
//until all have arrived.
//The cities are: Chennai, Bangalore and Pune.
public class Bus extends Thread{
	private Phaser phaser;
    private Random random;
     
    public Bus(Phaser phaser, String name) {
        this.phaser = phaser;
        setName(name);
        random = new Random();
    }
    
    private void goToChennai() {
        System.out.println(Thread.currentThread().getName() + " going to Chennai...");
        int sleep = random.nextInt(5);
        try {
            TimeUnit.SECONDS.sleep(sleep);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(Thread.currentThread().getName() + " arrived Chennai.");
        phaser.arriveAndAwaitAdvance();
    }
    
    private void goToBangalore() {
    	  System.out.println(Thread.currentThread().getName() + " going to Bangalore...");
          int sleep = random.nextInt(10);
          try {
              TimeUnit.SECONDS.sleep(sleep);
          } catch (InterruptedException e) {
              e.printStackTrace();
          }
          System.out.println(Thread.currentThread().getName() + " arrived in Bangalore.");
          phaser.arriveAndAwaitAdvance();
        /*
          if (Thread.currentThread().getName().equals("Bus 3")) {
              phaser.arriveAndDeregister();
              try {
                  TimeUnit.DAYS.sleep(50);
              } catch (InterruptedException e) {
                  e.printStackTrace();
              }
          } else {
              phaser.arriveAndAwaitAdvance();
          }*/
    }
    private void goToPune() {
        System.out.println((Thread.currentThread().getName() + " going toPune..."));
        phaser.arriveAndAwaitAdvance();
        System.out.println(Thread.currentThread().getName() + " arrived in Pune");
        
    }
    
    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName() + " is ready.");
        phaser.arriveAndAwaitAdvance(); //waiting for all busses to be ready
         
        goToChennai();
        goToBangalore();
        goToPune();
    }
}
