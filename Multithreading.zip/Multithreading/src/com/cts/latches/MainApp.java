package com.cts.latches;

import java.util.concurrent.CountDownLatch;

public class MainApp {

	public static void main(String[] args) {
		//A CountDownLatch is
		//initially created with a count of the number of events that must occur before the latch is
		//released.
	
		final CountDownLatch latch = new CountDownLatch(3);//initial count
	       Thread cacheService = new Thread(new SampleThread("CacheService", 1000, latch));
	       Thread alertService = new Thread(new SampleThread("AlertService", 1000, latch));
	       Thread validationService = new Thread(new SampleThread("ValidationService", 1000, latch));
	       Thread validationService1 = new Thread(new SampleThread("ValidationService", 1000, latch));
	       Thread validationService2 = new Thread(new SampleThread("ValidationService", 1000, latch));
	       Thread validationService3 = new Thread(new SampleThread("ValidationService", 1000, latch));
	       cacheService.start(); //separate thread will initialize CacheService
	       alertService.start(); //another thread for AlertService initialization
	       validationService.start();
	       validationService1.start();
	       validationService2.start();
	       validationService3.start();
	       try{
	            latch.await();  //main thread is waiting on CountDownLatch to finish
	            System.out.println("All services are up, Application is starting now");
	       }catch(InterruptedException ie){
	           ie.printStackTrace();
	       }
	     


	 
	}

}
