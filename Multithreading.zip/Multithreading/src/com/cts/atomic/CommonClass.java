package com.cts.atomic;

import java.util.concurrent.atomic.AtomicInteger;

public class CommonClass {
	private static final AtomicInteger count=new AtomicInteger(10);
	
	
	public static int inc()
	{

		 
		return count.incrementAndGet();
	}
	
	
	
}
