package com.cts.atomic;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.IntUnaryOperator;



public class AtomicIncrementer implements Counter {

	private final AtomicInteger counter = new AtomicInteger();
	 
	@Override
	public int getCount() {
		return counter.get();
	}
	
	@Override
	public final int increment(){
		return counter.incrementAndGet();
	}
	
	@Override
	public final int decrement(){
		return counter.decrementAndGet();
	}

	@Override
	public int getandUpdate() {
		// TODO Auto-generated method stub
		//counter.set(348);
		return counter.addAndGet(678);
		
		//return counter.updateAndGet(n -> (n > 0) ? n - 1 : n) > 0;
	}
 

}
