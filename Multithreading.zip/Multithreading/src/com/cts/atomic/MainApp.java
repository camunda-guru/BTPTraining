package com.cts.atomic;

public class MainApp {

	private Counter counter;
	 
	public static void main(String[] args) {
 
		MainApp counter = new MainApp();
		counter.init();
		
		
	}
 
	private void init() {
		
		counter = new AtomicIncrementer();
		
		for (int i = 0; i < 200; i++) {
			new Thread(new Increment(counter)).start();
			new Thread(new Decrement(counter)).start();
			new Thread(new Increment(counter)).start();
		}
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
 
		System.out.println("Final Counter " + counter.getCount());
 
	}
 
	
}
