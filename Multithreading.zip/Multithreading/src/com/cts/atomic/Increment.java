package com.cts.atomic;

public class Increment implements Runnable{

	private Counter counter;
	public Increment(Counter c)
	{
		counter=c;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(counter.getCount());
		counter.increment();
		System.out.println(counter.getandUpdate());
	}

}
