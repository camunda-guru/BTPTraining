package com.cts.atomic;

public interface Counter {
 
	int getandUpdate();
	
	int getCount();
	
	int increment();
	
	int decrement();
}
