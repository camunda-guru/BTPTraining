package com.cts.util;

import java.util.Random;

public class Toy implements Runnable {
	
	private Random random;
	private char[] ch;
	
	public Toy()
	{
		
		random = new Random();
	}
	public void run()
	{
	  int i=0,length;
		 try {
			
			ch =Thread.currentThread().getName().toCharArray();
			length=ch.length;
			while(length>0)
			{
				System.out.println(ch[i]);
				Thread.sleep(2000);
				i++;
				length--;
			}
			
			System.out.println("Generated Password:\t"+Thread.currentThread().getName()+random.nextInt(10000));
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	 
	}

}
