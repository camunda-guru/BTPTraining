package com.cts.util;

import java.util.Calendar;

public class GreetingThread implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		//System.out.println(Thread.currentThread().getName());
		
		
		Calendar calendar=null;
		
		
		calendar= Calendar.getInstance();
		//System.out.println(calendar.getTime().getHours());
		if(calendar.getTime().getHours()<=12)
			System.out.println("Good Morning");
		else
			System.out.println("Good Evening");
		
	}

}
