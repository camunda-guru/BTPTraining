package com.cts.util;

public class AccountThread implements Runnable{
private Account accountobj;
private String option;
private int amount;

public AccountThread(Account account,int amount,String option)
{
	accountobj=account;
	this.option=option;
	this.amount=amount;
}
	@Override
	public  synchronized void run() {
		// TODO Auto-generated method stub
		if(option.equals("Deposit"))
			accountobj.deposit(amount);
		else
			accountobj.withdraw(amount);
		
		System.out.println(accountobj.getBalance());
		
	}

}
