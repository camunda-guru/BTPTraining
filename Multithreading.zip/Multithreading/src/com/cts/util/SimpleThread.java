package com.cts.util;

public class SimpleThread extends Thread{

	public String name;
	public SimpleThread()
	{
		
	}
	public SimpleThread(String name)
	{
		super(name);
	}
	@Override
	public void run() {
		char[]  namearray=name.toCharArray();
	    for(char data:namearray)
	    {
	    	try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Interrupted");
				e.printStackTrace();
			}
	    	System.out.println(data);
	    }
		
	}
	
	

}
