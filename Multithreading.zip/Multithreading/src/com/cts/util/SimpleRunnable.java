package com.cts.util;

public class SimpleRunnable implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=0;i<100;i++)
			System.out.println(i);
	}

	public static void main(String[] args)
	{
		Thread thread = new Thread(new SimpleRunnable());
		thread.start();
	}
	
}
