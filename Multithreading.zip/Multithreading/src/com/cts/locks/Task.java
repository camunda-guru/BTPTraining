package com.cts.locks;

public interface Task {
	public void performTask();
}
