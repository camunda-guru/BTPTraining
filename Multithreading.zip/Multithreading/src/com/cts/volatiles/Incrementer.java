package com.cts.volatiles;

public class Incrementer extends Thread{
	
	private static volatile Integer count;
	
	public Incrementer(String name)
	{
		this.setName(name);
		count=new Integer(0);
	}
	@Override
	public synchronized void run()
	{
		
		count++;
		System.out.println(count +"updated by ---->"+ this.getName());
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}
