package com.cts.volatiles;

public class VolatileTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
           Incrementer inc1=new Incrementer("thread-1");
           Incrementer inc2=new Incrementer("thread-2");
           Incrementer inc3=new Incrementer("thread-3");
           Incrementer inc4=new Incrementer("thread-4");
           Incrementer inc5=new Incrementer("thread-5");
           inc1.start();
           inc2.start();
           inc3.start();
           inc4.start();
           inc5.start();
           
	}

}
