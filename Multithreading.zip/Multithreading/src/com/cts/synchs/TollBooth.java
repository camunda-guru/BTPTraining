package com.cts.synchs;

import java.util.Date;

public class TollBooth {
	
	public  void tollBoothMessage(int vno)
	{
		
		
			System.out.println(vno+"------>crossed the toll booth at---->"+new Date().toLocaleString());
		
	}

}
