package com.cts.synchs;

import java.util.Date;

public class Bridge {
	
	public void bridgeMessage(int vno)
	{
		
		

			System.out.println(vno+"----->crossed the bridge---->"+new Date().toLocaleString());
		
	}

}
