package com.cts.reentrants;

import java.util.concurrent.locks.ReentrantLock;

public class Display implements Runnable{
	private String threadName;
    ReentrantLock lock;
    Display(String threadName, ReentrantLock lock){
        this.threadName = threadName;
        this.lock = lock;
    }
    @Override
    public void run() {
        System.out.println("In Display run method, thread " + threadName + " is waiting to get lock");
        
        try {
            lock.lock();
            System.out.println("Thread " + threadName + "has got lock");
            methodA();
        } finally{
            lock.unlock();
        }
        
    }
    
    public void methodA(){
        System.out.println("In Display methodA, thread " + threadName + " is waiting to get lock");
       try {
            
            lock.lock();
            
            System.out.println("Thread " + threadName + "has got lock");
            System.out.println("Count of locks held by thread " + threadName + " - " + lock.getHoldCount());
            // Not calling unlock
            } finally{
            lock.unlock();
        }
    }

}
