package com.cts.cyclicbarriers;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class ParallelTasking  extends Thread{

	private CyclicBarrier cb;
	private int count;
    static int num1,num2,sum;
	public ParallelTasking(CyclicBarrier cyclicbarrier, String name) {
		cb=cyclicbarrier;
		this.setName(name);		
		
	}

	@Override
	public void run() {
		
		
		switch(this.getName())
		{
		case "Thread1":
			sum+=num2+10; 
			break;
		case "Thread2":
			sum+=num1+100; 
			break;
		case "Thread3":
			sum+=num2+890; 
			break;
		case "Thread4":
			sum+=num2+56; 
			break;
		case "Thread5":
			sum+=num2+56; 
			break;
		case "Thread6":
			sum+=num2+56; 
			break;
		}
		
		try {
			cb.reset();
			count=cb.await();
			if(count==0)
			{
			
				System.out.println(this.getName()+"with sum value"+sum);
				System.out.println("Reached Barrier");
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BrokenBarrierException e) {
			// TODO Auto-generated catch block
			System.out.println("can't wait");
		}
	}
	
	
	
	

}
