package com.cts.cyclicbarriers;

public class TaskAchieved implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		//System.out.println("Barrier task achieved");
	}

}
