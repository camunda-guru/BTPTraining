package com.cts.cyclicbarriers;

public class BarAction implements Runnable{

	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Barrier task achieved");
	}

}
