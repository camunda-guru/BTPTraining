package com.cts.cyclicbarriers.vip;

public class GoVIP implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		 // See
        System.out.println("Seeing");
        
        // Don't forget to say thanks to those
        // 50/- and 100/- queue people!! :)
        System.out.println("Thank you all");
	}

}
