package com.cts.cyclicbarriers.vip;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class HundredClass extends Thread {
	CyclicBarrier cb;

    public HundredClass(CyclicBarrier cb,String name)
    {
        // Take the CyclicBarrier object
        this.cb=cb;
        this.setName(name);
        // Let the 100/- queue move
        start();
    }
    
    public void run()
    {
        // They are just 2 km to go, because
        // they paid a double amount!
        System.out.println(this.getName()+"------->2 Km to go");
        try
        {
        	cb.reset();
            // Slow down, guys! Let the VIP go!
            cb.await();
        }catch(BrokenBarrierException e){
            System.out.println("We can't wait");
        } catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        // Great, you got it for 100!
        System.out.println("Hurray! We saw our GOD! +100");
    }
}
