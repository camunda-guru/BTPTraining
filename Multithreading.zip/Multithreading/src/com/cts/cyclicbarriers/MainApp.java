package com.cts.cyclicbarriers;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CyclicBarrier cb = new CyclicBarrier(3, new BarAction() );
		System.out.println("Starting");
		new MyThread(cb, "A");
		new MyThread(cb, "B");
		new MyThread(cb, "C");
		new MyThread(cb, "X");
		new MyThread(cb, "Y");
		new MyThread(cb, "Z");
		 
	}

}
