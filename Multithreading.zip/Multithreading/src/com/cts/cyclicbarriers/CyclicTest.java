package com.cts.cyclicbarriers;

import java.util.concurrent.CyclicBarrier;

public class CyclicTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CyclicBarrier cb =new CyclicBarrier(2,new TaskAchieved()); 
		ParallelTasking t1 =new ParallelTasking(cb,"Thread1");
		ParallelTasking t2 =new ParallelTasking(cb,"Thread2");
		ParallelTasking t3 =new ParallelTasking(cb,"Thread3");
		ParallelTasking t4 =new ParallelTasking(cb,"Thread4");
		ParallelTasking t5 =new ParallelTasking(cb,"Thread5");
		ParallelTasking t6 =new ParallelTasking(cb,"Thread6");
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		t5.start();
		t6.start();
		

	}

}
