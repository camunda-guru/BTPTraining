package com.cts.threaddemos;



public class HCLBB {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		BulletinBoard bb = new BulletinBoard();
		Thread t1 = new Thread(bb,"Publisher");
		Thread t2 = new Thread(bb,"Consumer");
		t1.start();
		t2.start();

	}

}
