package com.cts.threaddemos;

import java.util.ArrayList;
import java.util.Scanner;

import com.cts.entities.Answer;
import com.cts.entities.Question;



public class MainThreadDemo {

	public static void main(String[] args) {
		ArrayList<Question> questionlist= new ArrayList<Question>();
		// TODO Auto-generated method stub
		
	//Question1	
       Question question = new Question();
       question.setQuestionId(1);
       question.setQuestion("Capital");
       Answer answer=new Answer();
       answer.setAnswerId(1);
       answer.setAnswer("New Delhi");
       ArrayList<Answer> answerlist = new ArrayList<Answer>();
       answerlist.add(answer);
       answer=new Answer();
       answer.setAnswerId(2);
       answer.setAnswer("Chennai");
       answerlist.add(answer);
       answer=new Answer();
       answer.setAnswerId(3);
       answer.setAnswer("Bangalore");
       answerlist.add(answer);
	 question.setAnswerlist(answerlist);	
	 questionlist.add(question);
	 
	 //Question2
	   answerlist = new ArrayList<Answer>();
	 question = new Question();
     question.setQuestionId(1);
     question.setQuestion("JVM");
      answer=new Answer();
     answer.setAnswerId(1);
     answer.setAnswer("true");
 
     answerlist.add(answer);
     answer=new Answer();
     answer.setAnswerId(2);
     answer.setAnswer("False");
     answerlist.add(answer);
    
	 question.setAnswerlist(answerlist);	
	 questionlist.add(question);
	 
	 
		
	 
	   RBSQuiz rbsquiz = new RBSQuiz();
	   rbsquiz.questionlist=questionlist;
	   rbsquiz.start();
	   
	   

	   
	   
	   
		
	}

}
