package com.cts.threaddemos;

import java.util.concurrent.ForkJoinPool;

import com.cts.util.Account;
import com.cts.util.AccountThread;





public class SynchDemo {

	public static void main(String[] args) {
		
		//ForkJoinPool forkjoin = new ForkJoinPool();
		// TODO Auto-generated method stub
        Account account = new Account();
		AccountThread at = new AccountThread(account,6000,"Deposit");
		
		Thread t1 =new Thread(at);
		t1.start();
		Thread t2 =new Thread(at);
		t2.start();
		Thread t3 =new Thread(at);
		t3.start();
		 account = new Account();
		 at = new AccountThread(account,6000,"Withdraw");
		  t1 =new Thread(at);
			t1.start();
			t2 =new Thread(at);
			t2.start();
		 t3 =new Thread(at);
			t3.start();
		
	}

}
