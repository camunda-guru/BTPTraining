package com.cts.threaddemos;

import java.util.Scanner;

import com.cts.util.Toy;




public class ThreadMainDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Read UserName");
		String name=sc.nextLine();
		Toy t1 = new Toy();
		Thread thread1 = new Thread(t1,name);
		System.out.println("Read UserName");
		name=sc.nextLine();
		Toy t2 = new Toy();
		Thread thread2 = new Thread(t2,name);
		thread1.start();
		thread2.start();
		System.out.println(Thread.activeCount());
		System.out.println(thread1.isAlive());
	}

}
