package com.cts.threaddemos;

import com.cts.util.GreetingThread;

public class RunnableTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   
		GreetingThread greetingthread=new GreetingThread();
        Thread thread1= new Thread(greetingthread,"GTThread-1");
        thread1.start();
        Thread thread2= new Thread(greetingthread,"GTThread-2");
        thread2.start();
        Thread thread3= new Thread(greetingthread,"GTThread-3");
        thread3.start();
        //set thread priority
        thread1.setPriority(Thread.MAX_PRIORITY);
        thread2.setPriority(Thread.MIN_PRIORITY);
        thread3.setPriority(Thread.NORM_PRIORITY);
         //Get thread priority
        System.out.println(thread1.getName()+"\t"+thread1.getPriority());
        System.out.println(thread2.getName()+"\t"+thread2.getPriority());
        System.out.println(thread3.getName()+"\t"+thread3.getPriority());
	}

}
