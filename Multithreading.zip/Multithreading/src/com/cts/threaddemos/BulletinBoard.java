package com.cts.threaddemos;

public class BulletinBoard implements Runnable{

	private String message="No Message";
	
	public synchronized void Writer()
	{
		while(true)
		{
	   if(message.equals("No Message"))
	   {
		try {
			System.out.println(Thread.currentThread().getName());
			System.out.println("Writing.....");
			Thread.sleep(3000);
			message="Modi is our next PM";
			System.out.println("Message is Ready");
			notify();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   }
	   else
	   {
		   try {
			   System.out.println("Waiting...."+Thread.currentThread().getName());
			wait();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   }
	   
		}
		
	}
	public synchronized void Reader()
	{
		
		while(true)
		{
		    try {
		    	System.out.println(Thread.currentThread().getName());
		    	if(message.equals("No Message"))
				{
					System.out.println("Waiting.....");
					Thread.sleep(3000);
					wait();
				}
		    	else
		    	{
		    		Thread.sleep(3000);
		    		System.out.println(message);
		    		message="No Message";
		    		notify();
		    		
		    	}
			} 
		    catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
		
		
	}
	@Override
	public void run() throws IllegalMonitorStateException
	{
		if(Thread.currentThread().getName().equals("Publisher"))
			
			Writer();
		else
			Reader();
		
	}
	
}
