package com.cts.threaddemos;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;

import com.cts.entities.Answer;
import com.cts.entities.Question;



public class RBSQuiz  extends Thread{

	public ArrayList<Question> questionlist;
	
	private String response;
	private boolean status;
	@Override
	public void run() {
		// TODO Auto-generated method stub
		String[] correctanswer={"New Delhi","true"};
		int k=0;
		for(Question questiondata : questionlist)
		{
			//flag=false;
			System.out.print(questiondata.getQuestionId()+".");
			System.out.println(questiondata.getQuestion()+"?");
			ArrayList<Answer> answerdata= questiondata.getAnswerlist();
			for(Answer ans : answerdata)
			{
				System.out.print(ans.getAnswerId()+".");
				System.out.println(ans.getAnswer());
			}
			 System.out.println("Enter Answer: "  );
			int x = 10; // wait 2 seconds at most

			BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
			long startTime = System.currentTimeMillis();
			try {
				while ((System.currentTimeMillis() - startTime) < x * 1000
				        && !in.ready()) {
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			try {
				if (in.ready()) {
				   
				    response=in.readLine();
				} else {
				    System.out.println("You did not enter data....Timed out!");
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			    try
			   {
			    	if(response!=null)
			    	{
			    	if(response.equals(correctanswer[k]))
				      Thread.currentThread().interrupt();
			    	}
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				
			}
			k++;
		}
		
	}
}
	
	
	
	
	
	


