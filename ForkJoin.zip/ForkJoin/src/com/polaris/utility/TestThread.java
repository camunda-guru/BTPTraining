package com.polaris.utility;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class TestThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Runnable task = () -> {
		    String threadName = Thread.currentThread().getName();
		    System.out.println("Welcome " + threadName);
		};

		task.run();

		Thread thread = new Thread(task);
		thread.start();

		System.out.println("Done!");
		//
		Runnable runnable = () -> {
		    try {
		        String name = Thread.currentThread().getName();
		        System.out.println("Polaris " + name);
		        TimeUnit.SECONDS.sleep(1);
		        System.out.println("Virtusa " + name);
		    }
		    catch (InterruptedException e) {
		        e.printStackTrace();
		    }
		};

		Thread thread1 = new Thread(runnable);
		thread1.start();
		
		//Executors
		
		ExecutorService executor = Executors.newSingleThreadExecutor();
		executor.submit(() -> {
		    String threadName = Thread.currentThread().getName();
		    System.out.println("Hello " + threadName);
		});
		
		
		//callable
		Callable<Integer> task1 = () -> {
		    try {
		        TimeUnit.SECONDS.sleep(1);
		        return 123;
		    }
		    catch (InterruptedException e) {
		        throw new IllegalStateException("task interrupted", e);
		    }
		};
		
		ExecutorService executor1 = Executors.newFixedThreadPool(1);
		Future<Integer> future = executor.submit(task1);

		System.out.println("future done? " + future.isDone());

		Integer result;
		try {
			result = future.get();
			System.out.println("future done? " + future.isDone());
			System.out.print("result: " + result);
		} catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//timeout
		/*
		ExecutorService executor2 = Executors.newFixedThreadPool(1);

		Future<Integer> future2 = executor2.submit(() -> {
		    try {
		        TimeUnit.SECONDS.sleep(300);
		        return 123;
		    }
		    catch (InterruptedException e) {
		        throw new IllegalStateException("task interrupted", e);
		    }
		});

		try {
			future2.get(1, TimeUnit.SECONDS);
		} catch (InterruptedException | ExecutionException | TimeoutException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ExecutorService executor = Executors.newWorkStealingPool();

List<Callable<String>> callables = Arrays.asList(
        () -> "task1",
        () -> "task2",
        () -> "task3");

executor.invokeAll(callables)
    .stream()
    .map(future -> {
        try {
            return future.get();
        }
        catch (Exception e) {
            throw new IllegalStateException(e);
        }
    })
    .forEach(System.out::println);
    ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);

Runnable task = () -> System.out.println("Scheduling: " + System.nanoTime());
ScheduledFuture<?> future = executor.schedule(task, 3, TimeUnit.SECONDS);

TimeUnit.MILLISECONDS.sleep(1337);

long remainingDelay = future.getDelay(TimeUnit.MILLISECONDS);
System.out.printf("Remaining Delay: %sms", remainingDelay);
    
    ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);

Runnable task = () -> System.out.println("Scheduling: " + System.nanoTime());

int initialDelay = 0;
int period = 1;
executor.scheduleAtFixedRate(task, initialDelay, period, TimeUnit.SECONDS);
ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);

Runnable task = () -> {
    try {
        TimeUnit.SECONDS.sleep(2);
        System.out.println("Scheduling: " + System.nanoTime());
    }
    catch (InterruptedException e) {
        System.err.println("task interrupted");
    }
};

executor.scheduleWithFixedDelay(task, 0, 1, TimeUnit.SECONDS);
		*/
		
		
		//shutdown
				try {
				    System.out.println("attempt to shutdown executor");
				    executor.shutdown();
				    executor.awaitTermination(5, TimeUnit.SECONDS);
				}
				catch (InterruptedException e) {
				    System.err.println("tasks interrupted");
				}
				finally {
				    if (!executor.isTerminated()) {
				        System.err.println("cancel non-finished tasks");
				    }
				    executor.shutdownNow();
				    System.out.println("shutdown finished");
				}
	}
	
	

}
