package com.polaris.utility;

import java.util.concurrent.atomic.AtomicLong;

public class AtomicTest {
	private AtomicLong value = new AtomicLong(0L);
	public long next() {
		//value.incrementAndGet();
	return value.incrementAndGet();
	
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//AtomicLong aCounter = new AtomicLong(0L);
		//aCounter.incrementAndGet();
		AtomicTest test=new AtomicTest();
		for(int i=0;i<50;i++)
		  System.out.println(test.next());
		
	}

}
