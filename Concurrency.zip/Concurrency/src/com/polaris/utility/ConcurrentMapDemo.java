package com.polaris.utility;

import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentNavigableMap;
import java.util.concurrent.ConcurrentSkipListMap;

public class ConcurrentMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Country india=new Country("India",1000);
        Country japan=new Country("Japan",10000);
          
        Country france=new Country("France",2000);
        Country russia=new Country("Russia",20000);
        Country pakistan=new Country("Islamabad",20000);
        Country sa=new Country("riyadh",20000);
          
        ConcurrentHashMap<Country,String> countryCapitalMap=new ConcurrentHashMap<Country,String>();
        countryCapitalMap.put(india,"Delhi");
        countryCapitalMap.put(japan,"Tokyo");
        countryCapitalMap.put(france,"Paris");
        countryCapitalMap.put(russia,"Moscow");
        countryCapitalMap.put(pakistan,"Islamabad");
        countryCapitalMap.put(sa,"riyadh");
          
        Iterator<Country> countryCapitalIter=countryCapitalMap.keySet().iterator();//put debug point at this line
        while(countryCapitalIter.hasNext())
        {
            Country countryObj=countryCapitalIter.next();
            String capital=countryCapitalMap.get(countryObj);
          //  System.out.println(countryObj.getName()+"----"+capital);
            }
        
        countryCapitalMap.forEach(2, (key, value) ->
        System.out.printf("key: %s; value: %s; thread: %s\n",
            key, value, Thread.currentThread().getName()));

        String result = countryCapitalMap.reduce(1,
        	    (key, value) -> {
        	        System.out.println("Transform: " + Thread.currentThread().getName());
        	        System.out.println("f1...."+key+value);
        	        return key + "=" + value;
        	    },
        	    (s1, s2) -> {
        	    	
        	    	 System.out.println("f2...."+s1+s2);
        	        System.out.println("Reduce: " + Thread.currentThread().getName());
        	        return s1 + ", " + s2;
        	    });

        
    	System.out.println("Result: " + result);
    	//parralelism, reducing
        Object resultkeys =  countryCapitalMap.reduceKeys(1, (key,value)->{return key;});
        System.out.println("Keys"+resultkeys);
        
        //transformer
        String resulttransformer = countryCapitalMap.reduceKeys
        		(1, (key)->{return key.toString();},(s1,s2)->{return s1.toString()+s2.toString();});
        System.out.println("Tkeys"+resulttransformer);

        	ConcurrentMap<String,String> cMap = new ConcurrentHashMap<>();
        	cMap.put("one", "one");
        	System.out.println("Concurrent Map: " + cMap);
        	System.out.println(cMap.replace("one", "two"));
        	System.out.println("Concurrent Map: " + cMap);
        	System.out.println(cMap.putIfAbsent("two", "two"));
        	System.out.println(cMap.remove("one", "two"));        
        	System.out.println("Concurrent Map: " + cMap);
        
        	ConcurrentNavigableMap<String,String> map = new ConcurrentSkipListMap<String,String>();

        	map.put("1", "one");
        	map.put("2", "two");
        	map.put("3", "three");

        	ConcurrentNavigableMap<String,String> headMap = map.headMap("3");
        	System.out.println("Concurrent Map: " + headMap);
        	ConcurrentNavigableMap<String,String>  tailMap = map.tailMap("3");
        	System.out.println("Concurrent Map: " + tailMap);
        
        }
}

		
	

