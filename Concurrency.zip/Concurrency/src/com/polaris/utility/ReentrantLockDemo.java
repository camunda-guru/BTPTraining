package com.polaris.utility;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.ReentrantLock;

public class ReentrantLockDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExecutorService executor = Executors.newFixedThreadPool(2);
		ReentrantLock lock = new ReentrantLock();

		executor.submit(new Callable<String>() {
			
		    public String call() {
		    	lock.lock();
		    	try
		    	{
		    	try {
		    		System.out.println("First Callable Locked: " + lock.isLocked());
				    System.out.println("Held by me: " + lock.isHeldByCurrentThread());
					Thread.sleep(500);
					
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    	}
		    	finally
		    	{
		    		lock.unlock();
		    		System.out.println("First Callable finally Locked: " + lock.isLocked());
				    System.out.println("Held by me finally: " + lock.isHeldByCurrentThread());
		    	}
		        return "Task 3";
		    }
		});

		executor.submit(() -> {
		    System.out.println("Locked: " + lock.isLocked());
		    System.out.println("Held by me: " + lock.isHeldByCurrentThread());
		    boolean locked = lock.tryLock();
		    System.out.println("Lock acquired: " + locked);
		});

		executor.shutdown();
	}

}
