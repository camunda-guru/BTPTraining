package com.polaris.utility;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

public class CallableTask implements Callable<List<String>>{
	private int taskId;
	
	
	public CallableTask(int taskId) {
		super();
		this.taskId = taskId;
	}


	@Override
	public List<String> call() throws Exception {
		List<String> datalist= new ArrayList<String>();
	for(int i=0;i<5;i++)
	{
	String s="Callable Task Run at "+System.currentTimeMillis();
    datalist.add("TaskId----"+this.taskId+"----" + Thread.currentThread().getName()+"----"+s);
	}
	return datalist;
	}
}
