package com.polaris.utility;

import java.util.concurrent.Exchanger;

public class ExchangerRunnable implements Runnable {
	Exchanger exchanger = null;
    Object    object    = null;

    public ExchangerRunnable(Exchanger exchanger, Object object) {
        this.exchanger = exchanger;
        this.object = object;
    }

    public void run() {
        try {
        	
            Object previous = this.object;
            System.out.println(
                    Thread.currentThread().getName() +
                    " before exchange " + previous 
            );
     
            Object result = this.exchanger.exchange(this.object);

            System.out.println(
                    Thread.currentThread().getName() +
                    " exchanged " + previous + " for " + result
            );
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
