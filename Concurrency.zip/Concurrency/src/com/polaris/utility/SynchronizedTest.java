package com.polaris.utility;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.IntStream;

public class SynchronizedTest {
	ReentrantLock lock = new ReentrantLock();
	int count = 0;

	 void increment() {
		 lock.lock();
		 /*
		synchronized (this) {
	        count = count + 1;
	    }
	    */
		 try {
		        count++;
		    } finally {
		        lock.unlock();
		    }
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SynchronizedTest st = new SynchronizedTest();
		ExecutorService executor = Executors.newFixedThreadPool(2);

		IntStream.range(0, 10000)
		    .forEach(i -> executor.submit(st::increment));

		executor.shutdown();

		System.out.println(st.count);  // 9965
	}

}
