package com.polaris.utility;


import java.util.concurrent.ThreadFactory;

public class CustomThreadFactory implements ThreadFactory
{
	String name;
	   static int threadNo = 0;

	   public CustomThreadFactory (String name){
	       this.name = name;
	   }
//Constructs a new Thread. Implementations 
	   //may also initialize priority, name, daemon status, ThreadGroup, etc.
   @Override
   public Thread newThread(Runnable runnable)
   {
	   ++threadNo;
	     System.out.println("factory thread no:"+threadNo);
      Thread t = new Thread(runnable);
    t.setName("polaris"+threadNo);
      return t;
   }

   
}