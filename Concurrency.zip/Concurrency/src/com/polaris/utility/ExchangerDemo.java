package com.polaris.utility;

import java.util.concurrent.Exchanger;

public class ExchangerDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Exchanger exchanger = new Exchanger();

		ExchangerRunnable exchangerRunnable1 =
		        new ExchangerRunnable(exchanger, "5678");

		ExchangerRunnable exchangerRunnable2 =
		        new ExchangerRunnable(exchanger, "1234");

		new Thread(exchangerRunnable1).start();
		new Thread(exchangerRunnable2).start();
	}

}
