package com.polaris.utility;

public class Task implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println(Thread.currentThread().getName());
		
	}
 
	public static void main(String[] args)
	{
		Task  task1 = new Task ();
		Task task2 = new Task ();
		Task  task3 = new Task ();
		Thread t1 = new Thread(task1);
		Thread t2 = new Thread(task2);
		Thread t3 = new Thread(task3);
		t1.start();
		t2.start();
		t3.start();
	}
}
