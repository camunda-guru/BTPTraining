package com.polaris.utility;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class CallableTest {
	public static void main(String[] args) {
		// Step1 : Create a callable
		
		// Step 2: Configure Executor
		// Uses FixedThreadPool executor
		ExecutorService executor = Executors.newFixedThreadPool(2);
		List<Future<List<String>>> futurelist = new ArrayList<Future<List<String>>>();
		for(int i=0;i<5;i++)
		{
			Callable callableTask = new CallableTask(i);
		 Future<List<String>> future = executor.submit(callableTask);
		 futurelist.add(future);
		
		}
		
		List<String> result=null;
		boolean status = true;
		for(Future<List<String>> future: futurelist)
		{
			status=true;
			while(status)
			{
				
				try {
					if(future.isDone())
					{
					result = future.get();
					for(String str : result)
					{
						System.out.println(str);
				
          			}
					status=false;
					}
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ExecutionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		
		executor.shutdown();
	}
}
